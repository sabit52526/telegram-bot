# AdsGram setup for Taskly

## 1. Render environment variables

Add these in **Render > Service > Environment**:

```text
ADSGRAM_BLOCK_ID=54353
ADSGRAM_TOKEN=<copy from your AdsGram publisher profile>
ADSGRAM_USER_REWARD_USD=0.0005
ADSGRAM_REWARD_SECRET=<a long random secret>
ADSGRAM_REWARD_COOLDOWN_SEC=30
```

Keep `BOT_TOKEN` as it already exists. Do not commit any token or secret to GitHub.

`ADSGRAM_USER_REWARD_USD` is credited to a user's main balance for each accepted claim. Set it conservatively so total user rewards never exceed verified AdsGram revenue.

## 2. Secure the Reward URL

After setting `ADSGRAM_REWARD_SECRET`, edit the AdsGram Bot ad block Reward URL to:

```text
https://telegram-bot-19-p1l5.onrender.com/api/adsgram/reward?userId=[userId]&key=YOUR_SECRET
```

Replace `YOUR_SECRET` with the exact value used in Render. AdsGram requires the literal `[userId]` placeholder.

## 3. Deploy

Commit/push the modified files to GitHub. Render should redeploy automatically. The root route should show:

```text
Bot is alive and running 24/7!
```

A callback without a valid user should return an error. Never test by inserting a real user ID in a public browser after the bot is live because a valid callback credits balance.

## 4. How users receive tasks

When a user presses the existing Tasks button, the bot requests one live task from AdsGram. It sends:

- the protected sponsored message;
- the advertiser action button;
- the AdsGram Claim Reward button.

After AdsGram activates the claim link and calls the Reward URL, the bot credits `ADSGRAM_USER_REWARD_USD` to the user's main balance and records the event in `adsgram_rewards`.

## 5. Moderation

After deployment and testing, start AdsGram moderation. The bot must remain functional without forcing an ad for every action, rewards must be realistic, and genuine payout evidence may be requested.

## Important: Render storage

SQLite data on an ephemeral Render filesystem may disappear after a restart or redeploy. For real balances, attach a persistent disk and set, for example:

```text
DATABASE_PATH=/var/data/bot.db
```

If the current service does not support a persistent disk, migrate the database to managed PostgreSQL before accepting real-money users.
